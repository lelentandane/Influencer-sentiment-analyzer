(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const form = $("analyze-form");
  const submitBtn = $("submit-btn");
  const sampleBtn = $("sample-btn");
  const results = $("results");

  const EXAMPLE_BRAND = "Eco-friendly running shoes for beginner runners";
  const TIMEOUT_MS = 120000;
  const LOADING_STEPS = [
    "Fetching channel and video data",
    "Reading recent comments",
    "Classifying comments",
    "Scoring brand fit",
    "Putting the report together",
  ];

  const CATEGORIES = {
    supportive: { label: "Supportive", color: "#16a34a", what: "Specific praise or a personal experience tied to the content" },
    question: { label: "Questions", color: "#2563eb", what: "People asking about the content, products or creator" },
    critical: { label: "Critical", color: "#d97706", what: "Disagreement or criticism" },
    generic: { label: "Generic", color: "#94a3b8", what: "Low-effort reactions like \"nice\", \"first\" or emoji only" },
    spam: { label: "Spam", color: "#dc2626", what: "Promotion, links or bot-like text" },
    toxic: { label: "Toxic", color: "#7c3aed", what: "Insults or harassment" },
  };

  const TRUST_PARTS = {
    depth: ["Depth", "Share of comments that are specific and human (supportive, questions, critical)"],
    authenticity: ["Authenticity", "Share that is not spam or a copy-pasted template"],
    civility: ["Civility", "Share that is free of insults and harassment"],
  };

  const ENGAGEMENT_PARTS = {
    reach: ["Reach", "How much of the subscriber base watches"],
    interaction: ["Interaction", "How often viewers like a video"],
    conversation: ["Conversation", "How often viewers comment"],
    consistency: ["Consistency", "How steady views are from video to video"],
  };

  // ---------- safe DOM helpers ----------
  // All report text comes from third-party sites or an LLM, so it is only
  // inserted with textContent. Never use innerHTML here.
  function h(tag, opts = {}, ...children) {
    const node = document.createElement(tag);
    if (opts.class) node.className = opts.class;
    if (opts.text !== undefined) node.textContent = opts.text;
    if (opts.attrs) for (const [k, v] of Object.entries(opts.attrs)) node.setAttribute(k, v);
    for (const child of children) if (child) node.append(child);
    return node;
  }

  const hasNum = (n) => n !== null && n !== undefined;
  const tone = (n) => (!hasNum(n) ? "none" : n >= 75 ? "good" : n >= 55 ? "ok" : n >= 35 ? "warn" : "poor");
  const fmt = (n, digits = 0) => (hasNum(n) ? Number(n).toLocaleString(undefined, { maximumFractionDigits: digits, minimumFractionDigits: digits }) : "n/a");
  const pct = (share) => `${Math.round((share || 0) * 100)}%`;

  function ring(value) {
    const node = h("div", { class: `ring ${tone(value)}` }, h("span", { text: hasNum(value) ? value : "n/a" }));
    node.style.setProperty("--pct", hasNum(value) ? value : 0);
    return node;
  }

  function bar(label, value, help) {
    const row = h("div", { class: `bar-row ${tone(value)}` },
      h("div", { class: "bar-label" }, h("span", { text: label }),
        h("span", { class: "val", text: hasNum(value) ? `${value}/100` : "n/a" })),
      help ? h("p", { class: "bar-help", text: help }) : null);
    const fill = h("div", { class: "bar-fill" });
    fill.style.width = `${hasNum(value) ? value : 0}%`;
    row.append(h("div", { class: "bar-track" }, fill));
    return row;
  }

  function track(value) {
    const fill = h("div", { class: "bar-fill" });
    fill.style.width = `${hasNum(value) ? value : 0}%`;
    return h("div", { class: "bar-track" }, fill);
  }

  function card(title, ...children) {
    return h("section", { class: "card" }, h("h2", { text: title }), ...children);
  }

  // ---------- result sections ----------
  let chart = null;
  let afterRender = [];

  function renderSummary(d) {
    const o = d.overall;
    const stats = [d.creator.name];
    if (hasNum(d.creator.subscribers)) stats.push(`${fmt(d.creator.subscribers)} subscribers`);
    return h("section", { class: "card summary" },
      ring(o ? o.score : null),
      h("div", { class: "summary-text" },
        d.is_sample ? h("span", { class: "badge", text: "Sample data" }) : null,
        h("h2", { text: o ? o.label : "Not enough data to score" }),
        h("p", { text: o ? o.summary : "" }),
        h("p", { class: "muted small", text: stats.join(" | ") }),
        h("p", { class: "muted small", text: `Evaluated for: ${d.brand.description}` })));
  }

  function mini(label, value, meaning, naReason) {
    return h("div", { class: `mini ${tone(value)}` },
      h("div", { class: "label", text: label }),
      hasNum(value) ? h("div", { class: "value", text: value }) : h("div", { class: "value na", text: "Not available" }),
      track(value),
      h("p", { text: hasNum(value) ? meaning : naReason }));
  }

  function renderTrio(d) {
    const trust = d.audience && d.audience.trust ? d.audience.trust.score : null;
    const eng = d.engagement ? d.engagement.score : null;
    return h("div", { class: "trio" },
      mini("Audience quality", trust, "How real, specific and civil the comments are.", "No comments could be read."),
      mini("Engagement", eng, "How much of the audience watches and interacts.", "Needs YouTube channel data."),
      mini("Brand fit", d.brand_fit.fit_score, "How well the content matches your product.", ""));
  }

  function renderAudience(a) {
    if (!a) {
      return card("Audience quality", h("p", { class: "muted", text: "No comments could be read for this creator, so the audience was not scored." }));
    }
    const children = [];
    if (a.low_sample) {
      children.push(h("div", { class: "callout", text: `Only ${a.classified} comments were analyzed, so treat these results as a rough indication.` }));
    }

    // doughnut + legend
    const order = Object.keys(CATEGORIES);
    const canvas = h("canvas", { attrs: { role: "img", "aria-label": "Doughnut chart of comment categories. The legend lists the same numbers." } });
    const center = h("div", { class: "donut-center" }, h("div", {}, h("strong", { text: fmt(a.classified) }), h("span", { text: "comments analyzed" })));
    const legend = h("ul", { class: "legend" }, ...order.map((key) =>
      h("li", {},
        (() => { const dot = h("span", { class: "dot" }); dot.style.background = CATEGORIES[key].color; return dot; })(),
        h("span", { class: "name", text: CATEGORIES[key].label }),
        h("span", { class: "pct", text: pct(a.category_shares[key]) }),
        h("span", { class: "what", text: CATEGORIES[key].what }))));
    children.push(h("h4", { text: "What kind of comments are people leaving?" }),
      h("div", { class: "donut-row" }, h("div", { class: "donut" }, canvas, center), legend));
    afterRender.push(() => drawDonut(canvas, a, order));

    // sentiment
    const s = a.sentiment_shares;
    const seg = (key, color) => { const d = h("div", { attrs: { title: `${key}: ${pct(s[key])}` } }); d.style.width = `${(s[key] || 0) * 100}%`; d.style.background = color; return d; };
    const legendItem = (label, key, color) => { const dot = h("i"); dot.style.background = color; return h("span", {}, dot, document.createTextNode(`${label} ${pct(s[key])}`)); };
    children.push(h("h4", { text: "How do they feel about the creator?" }),
      h("div", { class: "stack" }, seg("positive", "#16a34a"), seg("neutral", "#94a3b8"), seg("negative", "#dc2626")),
      h("div", { class: "stack-legend" }, legendItem("Positive", "positive", "#16a34a"), legendItem("Neutral", "neutral", "#94a3b8"), legendItem("Negative", "negative", "#dc2626")));

    // trust breakdown
    if (a.trust) {
      children.push(h("h4", { text: `Audience trust score: ${a.trust.score}/100` }));
      for (const key of Object.keys(TRUST_PARTS)) {
        children.push(bar(TRUST_PARTS[key][0], Math.round(a.trust.components[key] * 100), TRUST_PARTS[key][1]));
      }
    }

    if (a.themes && a.themes.length) {
      children.push(h("h4", { text: "What the audience talks about" }),
        h("div", { class: "chips" }, ...a.themes.map((t) => h("span", { class: "chip", text: t }))));
    }

    if (a.signals && hasNum(a.signals.duplicate_ratio)) {
      children.push(h("h4", { text: "Automatic checks" }),
        h("p", { class: "muted small", text: `${pct(a.signals.duplicate_ratio)} of comments repeat the same text, ${pct(a.signals.spam_ratio)} contain links or promotion, and ${hasNum(a.signals.unique_author_ratio) ? pct(a.signals.unique_author_ratio) : "n/a"} of commenters are unique.` }));
    }
    return card("Audience quality", ...children);
  }

  function drawDonut(canvas, a, order) {
    if (!window.Chart) return;
    if (chart) chart.destroy();
    chart = new window.Chart(canvas, {
      type: "doughnut",
      data: {
        labels: order.map((k) => CATEGORIES[k].label),
        datasets: [{ data: order.map((k) => a.category_counts[k] || 0), backgroundColor: order.map((k) => CATEGORIES[k].color), borderWidth: 0 }],
      },
      options: { cutout: "68%", responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } },
    });
  }

  function metricTile(label, value, help) {
    return h("div", { class: "metric" }, h("div", { class: "m-label", text: label }),
      h("div", { class: "m-value", text: value }), h("p", { class: "m-help", text: help }));
  }

  function consistencyWord(cv) {
    if (!hasNum(cv)) return "n/a";
    return cv <= 0.5 ? "Steady" : cv <= 1 ? "Uneven" : "Spiky";
  }

  function renderEngagement(e) {
    if (!e) {
      return card("Engagement", h("p", { class: "muted", text: "Engagement needs channel data, so it is only available when you analyze a YouTube channel." }));
    }
    const m = e.metrics;
    const children = [bar("Engagement health", e.score, "Average of the four parts below, each compared with a benchmark.")];
    for (const key of Object.keys(ENGAGEMENT_PARTS)) {
      children.push(bar(ENGAGEMENT_PARTS[key][0], e.parts[key], ENGAGEMENT_PARTS[key][1]));
    }
    children.push(h("h4", { text: `The numbers behind it (last ${m.videos_analyzed} videos)` }),
      h("div", { class: "metrics" },
        metricTile("Typical views", fmt(m.median_views), "The middle view count across recent videos."),
        metricTile("Views per subscriber", fmt(m.views_per_subscriber, 2), "How much of the subscriber base watches. Higher is better."),
        metricTile("Likes per 1,000 views", fmt(m.likes_per_1k_views, 1), "A typical healthy channel sits around 20 to 50."),
        metricTile("Comments per 1,000 views", fmt(m.comments_per_1k_views, 1), "A typical healthy channel sits around 1 to 5."),
        metricTile("Posts per 30 days", fmt(m.posts_per_30_days, 1), "How often the creator publishes."),
        metricTile("View consistency", consistencyWord(m.view_variability), "Spiky means a few videos drive most of the views.")));
    return card("Engagement", ...children);
  }

  function renderFit(f) {
    const evidence = { strong: "Based on strong evidence", moderate: "Based on moderate evidence", thin: "Based on thin evidence, treat with care" }[f.evidence_strength];
    return card("Brand fit",
      bar("Fit with your product", f.fit_score),
      h("p", { class: "muted small", text: evidence }),
      h("p", { text: f.summary }),
      h("div", { class: "two-col" },
        h("div", {}, h("h4", { text: "Strengths" }), h("ul", { class: "list" }, ...f.strengths.map((s) => h("li", { text: s })))),
        h("div", {}, h("h4", { text: "Risks" }), h("ul", { class: "list" }, ...f.risks.map((s) => h("li", { text: s }))))),
      f.suggested_angle ? h("div", { class: "angle" }, h("strong", { text: "Idea for the collaboration: " }), document.createTextNode(f.suggested_angle)) : null);
  }

  function renderCost(c, d) {
    if (!c) {
      const reason = d.mode === "csv" ? "The cost estimate needs YouTube channel data." : "Enter the creator's fee in step 3 to see your cost per quality engagement.";
      return card("Cost estimate", h("p", { class: "muted", text: reason }));
    }
    return card("Cost estimate",
      h("div", { class: "cost-big", text: fmt(c.cost_per_quality_engagement, 2) }),
      h("p", { class: "cost-sub", text: "cost per quality engagement, in the same currency as the fee" }),
      h("div", { class: "formula", text:
        `fee ${fmt(c.fee)} / (typical views ${fmt(c.expected_views)} x interaction rate ${(c.interaction_rate * 100).toFixed(2)}% x authenticity ${pct(c.authenticity)})\n= fee / ${fmt(c.quality_engagements, 1)} quality engagements` }),
      h("p", { class: "muted small", text: "A quality engagement is a like or comment that is not spam or a copy-pasted template. This assumes a sponsored video performs like a typical recent video." }));
  }

  function renderMethod() {
    const details = h("details", { class: "method card" }, h("summary", { text: "How these numbers are calculated" }),
      h("p", { text: "Every score is out of 100. The weights and benchmarks are sensible defaults, not industry standards, so use the scores to compare creators and spot problems, not as exact measurements." }),
      h("ul", { class: "list" },
        h("li", { text: "Audience quality (40%): depth 50%, authenticity 35%, civility 15%, based on how an AI model classifies a sample of up to 150 recent comments, plus rule-based spam and duplicate checks." }),
        h("li", { text: "Brand fit (35%): an AI model compares the creator's description, recent video titles and audience topics with your product." }),
        h("li", { text: "Engagement (25%): views per subscriber, likes and comments per 1,000 views, and consistency, each scored against a benchmark." }),
        h("li", { text: "If a part cannot be measured, it is left out and the remaining weights are rescaled." })));
    return details;
  }

  function render(d) {
    afterRender = [];
    results.replaceChildren();
    for (const message of d.warnings || []) results.append(h("div", { class: "banner warn", text: message }));
    results.append(renderSummary(d), renderTrio(d), renderAudience(d.audience), renderEngagement(d.engagement),
      renderFit(d.brand_fit), renderCost(d.cost, d), renderMethod());
    results.hidden = false;
    for (const fn of afterRender) fn();
    results.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  // ---------- loading and errors ----------
  let stepTimer = null;

  function setLoading(on) {
    submitBtn.disabled = on;
    sampleBtn.disabled = on;
    $("loading").hidden = !on;
    clearInterval(stepTimer);
    if (!on) return;
    let active = 0;
    const paint = () => $("loading-steps").replaceChildren(...LOADING_STEPS.map((text, i) =>
      h("li", { class: i < active ? "done" : i === active ? "active" : "", text })));
    paint();
    stepTimer = setInterval(() => { active = Math.min(active + 1, LOADING_STEPS.length - 1); paint(); }, 4500);
  }

  function clearErrors() {
    $("form-error").hidden = true;
    for (const el of form.querySelectorAll("[aria-invalid]")) el.removeAttribute("aria-invalid");
  }

  function fail(message, fieldId) {
    const box = $("form-error");
    box.textContent = message;
    box.hidden = false;
    if (fieldId) {
      const field = $(fieldId);
      field.setAttribute("aria-invalid", "true");
      field.focus();
    }
  }

  function errorMessage(body, status) {
    if (body && typeof body.detail === "string") return body.detail;
    if (body && Array.isArray(body.detail) && body.detail.length) return `Please check the form: ${body.detail[0].msg}.`;
    return `The request failed (status ${status}).`;
  }

  async function run(url, options = {}) {
    clearErrors();
    results.hidden = true;
    setLoading(true);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
      const res = await fetch(url, { ...options, signal: controller.signal });
      let body = null;
      try { body = await res.json(); } catch { /* non-JSON error page */ }
      if (!res.ok) throw new Error(errorMessage(body, res.status));
      render(body);
    } catch (err) {
      if (err.name === "AbortError") fail("The analysis took too long and was stopped. Please try again.");
      else if (err instanceof TypeError) fail("Could not reach the server. Is the backend running?");
      else fail(err.message);
    } finally {
      clearTimeout(timer);
      setLoading(false);
    }
  }

  // ---------- tabs ----------
  let mode = "youtube";

  function setMode(next) {
    mode = next;
    for (const m of ["youtube", "csv"]) {
      $(`tab-${m}`).setAttribute("aria-selected", String(m === next));
      $(`panel-${m}`).hidden = m !== next;
    }
    clearErrors();
  }

  $("tab-youtube").addEventListener("click", () => setMode("youtube"));
  $("tab-csv").addEventListener("click", () => setMode("csv"));

  $("example-btn").addEventListener("click", () => {
    $("brand").value = EXAMPLE_BRAND;
    $("brand").focus();
  });

  // ---------- submit ----------
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    clearErrors();

    const data = new FormData();
    data.append("mode", mode);

    if (mode === "youtube") {
      const creator = $("creator").value.trim();
      if (!creator) return fail("Enter the creator's YouTube handle or channel link.", "creator");
      data.append("creator", creator);
    } else {
      const file = $("comments-file").files[0];
      const description = $("creator-description").value.trim();
      if (!file) return fail("Choose a CSV file of comments.", "comments-file");
      if (description.length < 10) return fail("Describe what the creator posts about, in at least a short sentence.", "creator-description");
      data.append("comments_file", file);
      data.append("creator_description", description);
      const name = $("creator-name").value.trim();
      if (name) data.append("creator", name);
    }

    const brand = $("brand").value.trim();
    if (brand.length < 10) return fail("Describe the product you want to promote, in at least a short sentence.", "brand");
    data.append("brand_description", brand);

    const audience = $("audience").value.trim();
    if (audience) data.append("target_audience", audience);
    const fee = $("fee").value.trim();
    if (fee) data.append("fee", fee);

    run("/api/analyze", { method: "POST", body: data });
  });

  sampleBtn.addEventListener("click", () => run("/api/sample"));

  // ---------- server status ----------
  async function checkStatus() {
    const banner = $("status-banner");
    try {
      const res = await fetch("/api/status");
      const s = await res.json();
      if (!s.llm || !s.youtube) {
        const missing = [!s.llm ? "an Anthropic key" : null, !s.youtube ? "a YouTube key" : null].filter(Boolean).join(" and ");
        banner.textContent = `Live analysis is not fully set up on this server (missing ${missing}). You can still explore the sample report.`;
        banner.hidden = false;
      }
    } catch {
      banner.textContent = "Cannot reach the server. Start the backend, then reload this page.";
      banner.hidden = false;
    }
  }

  checkStatus();
})();
